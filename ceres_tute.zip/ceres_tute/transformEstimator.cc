/*
 * Pose adjustmer using keypoint likelihoods from a single image
 * Author: Krishna Murthy
*/

#include <cmath>
#include <cstdio>
#include <fstream>
#include <iostream>

#include <ceres/loss_function.h>
#include <ceres/iteration_callback.h>
#include <ceres/rotation.h>

// Contains definitions of various problem structs
#include "problemStructs.hpp"
// Contains various cost function struct specifications
#include "costFunctions.hpp"


int main(int argc, char** argv){

	google::InitGoogleLogging(argv[0]);

	const char *cubeFileName;
	const char *referenceCubeFileName;
	const char *outputFileName;

	cubeFileName = "../data/cube.txt";
	referenceCubeFileName = "../data/cube_shifted.txt";
	outputFileName = "ceres_output.txt";

	// Create a 'SingleViewPoseAdjustmentProblem' instance to hold the BA problem
	TranslationProblem myProblem;
	// Read the problem file and store relevant information
	if(!myProblem.loadFile(cubeFileName, referenceCubeFileName)){
		std::cerr << "ERROR: Unable to open file " << cubeFileName << " or " << referenceCubeFileName << std::endl;
		return 1;
	}

 	return 0;

}
